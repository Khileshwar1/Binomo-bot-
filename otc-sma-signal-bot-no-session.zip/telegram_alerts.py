import logging
import requests


log = logging.getLogger("telegram")


class TelegramAlerter:
    def __init__(self, token: str, chat_id: str):
        self.token = token
        self.chat_id = chat_id

    def enabled(self) -> bool:
        return bool(self.token and self.chat_id)

    def send(self, text: str) -> bool:
        if not self.enabled():
            log.warning("Telegram is not configured; signal printed only.")
            return False

        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        try:
            r = requests.post(
                url,
                json={"chat_id": self.chat_id, "text": text},
                timeout=15,
            )
            r.raise_for_status()
            return True
        except requests.RequestException as exc:
            log.error("Telegram error: %s", exc)
            return False
