# OTC SMA20/SMA40 Signal Bot

GitHub-ready Python signal bot using the `tradingview-screener` package.

## Strategy

- Trend timeframe: **5 minutes**
- Entry timeframe: **1 minute**
- Indicators: **SMA20 and SMA40**
- BUY: 5M SMA20 > SMA40 AND 1M SMA20 > SMA40
- SELL: 5M SMA20 < SMA40 AND 1M SMA20 < SMA40
- A new alert is emitted only when the pair changes from another state to BUY/SELL.
- Signals are alerts only. This project does **not** place trades.

TradingView's screener package exposes timeframe-specific fields such as `SMA20|1`, `SMA20|5`, `SMA40|1`, and `SMA40|5`.

## Important OTC limitation

The symbols shown in a broker app as `EUR/USD (OTC)`, `USD/JPY (OTC)`, etc. are not automatically the same feed as a normal TradingView forex symbol.

The default mapping in `config.py` uses ordinary TradingView symbols such as `OANDA:USDJPY`. This is useful for testing the strategy, but it should NOT be assumed to reproduce the broker's OTC price.

For exact broker OTC signals, replace each value in `config.py` with the exact TradingView symbol/feed that corresponds to your intended data source.

## 1. Local setup

Python 3.10+ recommended.

```bash
git clone <your-repository-url>
cd otc-sma-signal-bot

python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows:
# .venv\Scripts\activate

pip install -r requirements.txt
cp .env.example .env
python bot.py
```

On Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

## 2. Telegram

Create a Telegram bot with BotFather, then put the bot token and chat ID in `.env`.

```text
TELEGRAM_BOT_TOKEN=...
TELEGRAM_CHAT_ID=...
```

If Telegram values are blank, signals are printed in the terminal only.

## 3. TradingView session cookie

The public screener can return delayed data. The package documentation notes that authenticated cookies may be needed for live data, and OTC instruments can still have a delayed feed depending on the TradingView subscription/data entitlement.

Do not commit your real `sessionid` to GitHub.

Put it only in `.env`:

```text
TRADINGVIEW_SESSIONID=your_sessionid
```

## 4. Test one polling cycle

```bash
RUN_ONCE=true python bot.py
```

## 5. Run continuously

```bash
python bot.py
```

The bot polls every 60 seconds by default.

## 6. Add/change pairs

Edit `config.py`.

Example:

```python
CONFIG = {
    "USD/JPY (OTC)": "OANDA:USDJPY",
    "EUR/USD (OTC)": "OANDA:EURUSD",
}
```

The left side is the label sent to Telegram. The right side is the TradingView ticker.

## GitHub Actions

`.github/workflows/test.yml` only runs syntax/import tests. It does not keep a trading bot running continuously because GitHub Actions is not intended to be a persistent market-data process.

For continuous operation use a suitable always-on host/VPS/container service.

## Risk note

SMA signals do not guarantee profitable trades. OTC/binary-style products can have a different price-generation/feed structure from the underlying market. Validate the data source and backtest/paper-test before risking money.


## No-session mode

The bot can run with **no `sessionid`**. In that mode it uses TradingView's
anonymous/public screener endpoint. The data may be delayed, so the bot
prints a warning and should be treated as a testing/signal prototype rather
than a guaranteed live OTC feed.

For desktop use, you can optionally install `rookiepy` and set:

```text
USE_BROWSER_COOKIES=true
```

The bot will attempt to read your own local Chrome TradingView cookies. Keep
the bot on a machine you control and never commit cookies to GitHub.

For OTC specifically, TradingView can still return delayed OTC data even when
authenticated, depending on your market-data entitlement. The OTC feed must
therefore be verified independently.
