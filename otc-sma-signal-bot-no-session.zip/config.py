# TradingView symbol mapping.
# IMPORTANT: These are TradingView symbols, not guaranteed to be the same
# OTC feed used by a broker/app. Replace them with the exact TradingView
# symbols that match your intended feed when available.

CONFIG = {
    "EUR/USD (OTC)": "OANDA:EURUSD",
    "GBP/USD (OTC)": "OANDA:GBPUSD",
    "USD/JPY (OTC)": "OANDA:USDJPY",
    "USD/CHF (OTC)": "OANDA:USDCHF",
    "NZD/JPY (OTC)": "OANDA:NZDJPY",
    "AUD/NZD (OTC)": "OANDA:AUDNZD",
    "EUR/GBP (OTC)": "OANDA:EURGBP",
    "GOLD (OTC)": "OANDA:XAUUSD",
    "AMAZON (OTC)": "NASDAQ:AMZN",
    "APPLE (OTC)": "NASDAQ:AAPL",
    "TESLA (OTC)": "NASDAQ:TSLA",
    "GOOGLE (OTC)": "NASDAQ:GOOGL",
    # The following are screenshot labels; their exact TradingView symbols
    # are broker/platform-specific and should be mapped before enabling.
    # "BIN IDX": "EXCHANGE:SYMBOL",
    # "IMX": "EXCHANGE:SYMBOL",
    # "PMX": "EXCHANGE:SYMBOL",
    # "ASIA": "EXCHANGE:SYMBOL",
}
