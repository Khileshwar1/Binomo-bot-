from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional


@dataclass
class Signal:
    pair: str
    ticker: str
    side: str
    price: float
    sma20_1m: float
    sma40_1m: float
    sma20_5m: float
    sma40_5m: float
    reason: str
    timestamp: str

    def to_message(self) -> str:
        icon = "🟢" if self.side == "BUY" else "🔴"
        return (
            f"{icon} {self.side} SIGNAL\n\n"
            f"Pair: {self.pair}\n"
            f"TV: {self.ticker}\n"
            f"Entry TF: 1M\n"
            f"Trend TF: 5M\n"
            f"Price: {self.price}\n"
            f"SMA20 (1M): {self.sma20_1m}\n"
            f"SMA40 (1M): {self.sma40_1m}\n"
            f"SMA20 (5M): {self.sma20_5m}\n"
            f"SMA40 (5M): {self.sma40_5m}\n"
            f"Reason: {self.reason}\n"
            f"UTC: {self.timestamp}"
        )


class SignalEngine:
    """
    Strategy:
      5m bullish trend: SMA20 > SMA40
      5m bearish trend: SMA20 < SMA40

      1m entry:
        BUY when 1m SMA20 > SMA40 and 5m trend is bullish
        SELL when 1m SMA20 < SMA40 and 5m trend is bearish

    A signal is emitted only when the 1m state changes, preventing a new
    alert every minute while the same condition remains true.
    """

    def __init__(self):
        self.last_state = {}

    @staticmethod
    def _num(row, key):
        value = row.get(key)
        if value is None:
            return None
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    def evaluate(self, pair: str, ticker: str, row: dict) -> Optional[Signal]:
        price = self._num(row, "close|1")
        sma20_1 = self._num(row, "SMA20|1")
        sma40_1 = self._num(row, "SMA40|1")
        sma20_5 = self._num(row, "SMA20|5")
        sma40_5 = self._num(row, "SMA40|5")

        values = [price, sma20_1, sma40_1, sma20_5, sma40_5]
        if any(v is None for v in values):
            return None

        if sma20_5 > sma40_5 and sma20_1 > sma40_1:
            state = "BUY"
            reason = "5M bullish + 1M SMA20 above SMA40"
        elif sma20_5 < sma40_5 and sma20_1 < sma40_1:
            state = "SELL"
            reason = "5M bearish + 1M SMA20 below SMA40"
        else:
            state = "WAIT"
            reason = "timeframes not aligned"

        previous = self.last_state.get(pair)
        self.last_state[pair] = state

        if state in ("BUY", "SELL") and state != previous:
            return Signal(
                pair=pair,
                ticker=ticker,
                side=state,
                price=price,
                sma20_1m=sma20_1,
                sma40_1m=sma40_1,
                sma20_5m=sma20_5,
                sma40_5m=sma40_5,
                reason=reason,
                timestamp=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
            )

        return None
