from __future__ import annotations

import logging
from typing import Optional

from tradingview_screener import Query

log = logging.getLogger("tradingview")

COLUMNS = [
    "name",
    "close",
    "close|1",
    "close|5",
    "SMA20|1",
    "SMA40|1",
    "SMA20|5",
    "SMA40|5",
]


class TradingViewData:
    """
    Works without a TradingView session.

    Anonymous mode may be delayed. If USE_BROWSER_COOKIES=true and the
    optional rookiepy package is installed, the bot tries to load the
    user's local TradingView cookies. This is optional and never writes
    credentials into the project.
    """

    def __init__(self, sessionid: Optional[str] = None):
        self.cookies = None

        if sessionid:
            self.cookies = {"sessionid": sessionid}
            log.info("TradingView session cookie configured.")
            return

        use_browser = False
        import os
        use_browser = os.getenv("USE_BROWSER_COOKIES", "false").lower() == "true"

        if use_browser:
            try:
                import rookiepy
                self.cookies = rookiepy.chrome([".tradingview.com"])
                log.info("Loaded TradingView cookies from Chrome.")
            except Exception as exc:
                log.warning("Browser cookies unavailable: %s", exc)

        if self.cookies is None:
            log.warning(
                "Running in anonymous TradingView mode. Data may be delayed; "
                "this is NOT guaranteed live OTC data."
            )

    def get_symbol(self, ticker: str) -> Optional[dict]:
        q = Query().select(*COLUMNS).set_tickers(ticker).limit(1)

        if self.cookies:
            _, df = q.get_scanner_data(cookies=self.cookies)
        else:
            _, df = q.get_scanner_data()

        if df.empty:
            return None

        return df.iloc[0].to_dict()
