from signal_engine import SignalEngine


def row(bull=True):
    return {
        "close|1": 100.0,
        "SMA20|1": 101.0 if bull else 99.0,
        "SMA40|1": 100.0,
        "SMA20|5": 102.0 if bull else 98.0,
        "SMA40|5": 100.0,
    }


def test_buy_signal():
    e = SignalEngine()
    s = e.evaluate("TEST", "OANDA:EURUSD", row(True))
    assert s is not None
    assert s.side == "BUY"


def test_sell_signal():
    e = SignalEngine()
    s = e.evaluate("TEST", "OANDA:EURUSD", row(False))
    assert s is not None
    assert s.side == "SELL"


def test_duplicate_state_is_suppressed():
    e = SignalEngine()
    assert e.evaluate("TEST", "OANDA:EURUSD", row(True)) is not None
    assert e.evaluate("TEST", "OANDA:EURUSD", row(True)) is None
