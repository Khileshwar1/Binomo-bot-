import logging
import os
import time
from datetime import datetime, timezone

from dotenv import load_dotenv

from config import CONFIG
from signal_engine import SignalEngine
from tradingview_data import TradingViewData
from telegram_alerts import TelegramAlerter

load_dotenv()

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s | %(levelname)s | %(message)s",
)
log = logging.getLogger("otc-sma-bot")


def main():
    data = TradingViewData(
        sessionid=os.getenv("TRADINGVIEW_SESSIONID", "").strip() or None
    )
    alerter = TelegramAlerter(
        token=os.getenv("TELEGRAM_BOT_TOKEN", "").strip(),
        chat_id=os.getenv("TELEGRAM_CHAT_ID", "").strip(),
    )
    engine = SignalEngine()

    poll_seconds = int(os.getenv("POLL_SECONDS", "60"))
    once = os.getenv("RUN_ONCE", "false").lower() == "true"

    log.info("Starting OTC SMA20/SMA40 signal bot")
    log.info("5m trend + 1m entry | poll=%ss", poll_seconds)

    while True:
        for pair, ticker in CONFIG.items():
            try:
                row = data.get_symbol(ticker)
                if row is None:
                    log.warning("%s | no data for %s", pair, ticker)
                    continue

                signal = engine.evaluate(pair, ticker, row)
                if signal:
                    text = signal.to_message()
                    log.info("\n%s", text)
                    alerter.send(text)
            except Exception:
                log.exception("%s | processing error", pair)

        if once:
            break

        time.sleep(max(10, poll_seconds))


if __name__ == "__main__":
    main()
